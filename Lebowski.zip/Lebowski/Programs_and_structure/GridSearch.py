#for efficiency reasons we did the grid search on the whole dataset
# coding: utf-8
# In[ ]:

from datetime import datetime
import pandas as pd
from Calculhoraire_exclusif import intervalle
from Calculhoraire_exclusif import centre
from Calculhoraire_exclusif import holidays
from Calculhoraire_exclusif import inverse
from sklearn.tree import DecisionTreeRegressor
from sklearn import ensemble
from sklearn.model_selection import GridSearchCV
import numpy as np
from math import ceil
import time

start_time = time.time()

read_name = 'train/train_week_centre_time_date.csv'
print("loading data...")
df = pd.read_csv(read_name, sep = ",")
print("end loading\n")

df['WEEK_END']=df['DAY_WE_DS'].apply(lambda x:     int(x>=5))

assign = np.unique(df.ASS_ASSIGNMENT)
print(assign)

print(time.time()-start_time)
start_time = time.time()
# In[ ]:

#grid_search for best parameters
cross = []
param = []
for i in assign:
    cross.append(ensemble.GradientBoostingRegressor(loss='ls', criterion='friedman_mse',
                                                    init=None, 
                                                    random_state=None, max_features=None, verbose=0, 
                                                    max_leaf_nodes=None, warm_start=False, presort='auto'))

#choose the parameters for a grid search (it can be very long, depending on the size of the grid)
param_grid = {"n_estimators": [1000,1500],  
              'learning_rate': [0.1, 0.01],
              'max_depth': [1,5]}

print("cross_fitting")
for i in assign:
    start_time = time.time()
    Matrix = df[df["ASS_ASSIGNMENT"]==i]
    Matrix = Matrix[['YEAR','MONTH','DAY','TIME_SLOT','DAY_WE_DS','WEEK_END']]
    Result = df[df['ASS_ASSIGNMENT']==i]
    Result = Result['CSPL_RECEIVED_CALLS']
    print(i)
    print('searching...')
    #gs_cv = GridSearchCV(cross[i], param_grid).fit(Matrix, Result)
    gs_cv = GridSearchCV(cross[i], param_grid).fit(Matrix, Result)
    print('end!')
    print('Time = ')
    print(time.time()-start_time + 's')
    start_time = time.time()
    print()
    param.append(gs_cv.best_params_)
print("end fitting")


# In[ ]:
#best parameters found
print('Best parameters :')
print(param)



