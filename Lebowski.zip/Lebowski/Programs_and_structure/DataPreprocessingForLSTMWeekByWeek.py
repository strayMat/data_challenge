
# coding: utf-8

# In[1]:

from datetime import datetime
from datetime import timedelta
import pandas as pd
from Calculhoraire_exclusif import intervalle
from Calculhoraire_exclusif import centre
from Calculhoraire_exclusif import holidays
from Calculhoraire_exclusif import inverse
from sklearn.tree import DecisionTreeRegressor
from sklearn import ensemble
import numpy as np
from math import ceil

predict_intervals = pd.read_csv('predict_weeks/intervals.csv', sep=';')

predict_intervals = predict_intervals.as_matrix()


# In[2]:

read_name = 'train/train_week_centre_time_date.csv'
print("loading data...")
df = pd.read_csv(read_name, usecols = ['short_DATE', 'TIME_SLOT', 'ASS_ASSIGNMENT', 'CSPL_RECEIVED_CALLS'], sep = ",")
print("end loading\n")

start = datetime(2011,1,1)
start = start.date()

df['short_DATE']=df['short_DATE'].apply(lambda x:     datetime.strptime(x,"%Y-%m-%d"))
df['ABSOLUTE']=0

print('converting in absolute time...')
for i, row in df.iterrows():
    df.set_value(i,'ABSOLUTE',((row['short_DATE'].date()-start).days)*48+row['TIME_SLOT'])

centers = df['ASS_ASSIGNMENT'].unique()

print('end!')

# In[3]:

df = df.groupby(['ABSOLUTE', 'ASS_ASSIGNMENT'])['CSPL_RECEIVED_CALLS'].sum()

# In[4]:

df2 = df.to_dict()

# In[9]:

total = 21*48
write = [[0 for k in range(2)] for l in range(total)]

print('writing data in separate folders (one for each week)...')

for i in range(12):
    start = predict_intervals[i][0]
    end = predict_intervals[i][1]
    time_begin = start-total
    for a in centers:
        for time in range(total):
            s = time+time_begin
            write[time][0]=df2.get((s,a),0)
        for time in range(total-1):
            write[time][1]=write[time+1][0]
        write[total-1][1]=None
        data = pd.DataFrame(write)
        data.to_csv('time_series/'+str(i)+'/'+str(inverse(a))+'.csv', sep = ';', header=['Current', 'Next'], index=False)

print('end!')



