
# coding: utf-8

# In[42]:

from datetime import datetime
import pandas as pd
from Calculhoraire_exclusif import intervalle
from Calculhoraire_exclusif import centre
from Calculhoraire_exclusif import holidays
from Calculhoraire_exclusif import inverse
from sklearn.tree import DecisionTreeRegressor
from sklearn import ensemble
import numpy as np
from math import exp
from math import log
from math import ceil
from math import floor

dsub = pd.read_csv('submission/submission.txt', usecols=['DATE'], sep = "\t")

start = '2011-01-01 00:00:00.000'
start = datetime.strptime(start, "%Y-%m-%d %H:%M:%S.%f")
start = start.date()

dsub['DATE'] = dsub['DATE'].apply(lambda x:     datetime.strptime(x,"%Y-%m-%d %H:%M:%S.%f"))

dsub['DATE']=dsub['DATE'].dt.date

dates = dsub['DATE'].unique()
dates.sort()

# In[43]:

i=0
intervals = [[0,0] for i in range(12)]
while i < len(dates):
    time1 = ((dates[i] - start).days)*48
    i+=6
    time2 = ((dates[i] - start).days)*48
    
    intervals[floor(i/7)][0] = time1
    intervals[floor(i/7)][1] = time2
    i+=1

# In[53]:

data = pd.DataFrame(intervals, columns = ['start', 'end'])

# In[50]:
print('Weeks to be predicted in absolute time')

print(intervals)

# In[55]:

data.to_csv('predict_weeks/intervals.csv', sep = ';', index=False)



