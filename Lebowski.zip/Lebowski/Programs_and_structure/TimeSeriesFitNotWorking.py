#It is not working !!


# coding: utf-8

# In[ ]:

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
from Calculhoraire_exclusif import centre
from Calculhoraire_exclusif import inverse
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error

#for reproductibility of results
numpy.random.seed(7)

predict_intervals = pd.read_csv('predict_weeks/intervals.csv', sep=';')

predict_intervals = predict_intervals.as_matrix()

# In[ ]:

#trying for each week to learn on the last 3 weeks
for i in range(1):
    for w in range(1):
        df = pandas.read_csv('time_series/'+str(w)+'/'+str(inverse(i))+'.csv', usecols=['Current', 'Next'], sep = ';')
        #drop last row
        df=df[:-1]
        #transform and fit
        dataset = df.values
        dataset = dataset.astype('float32')
        scaler = MinMaxScaler(feature_range=(0, 1))
        dataset = scaler.fit_transform(dataset)
        dataset = np.insert(dataset, 1, 1, axis=1)
        
        model = Sequential()
        model.add(LSTM(4, input_dim=1, input_shape=dataset.shape[1:]))
        model.add(Dense(1))
        model.compile(loss='mean_squared_error', optimizer='adam',metrics=['accuracy'])
	#trying to debug
        model.fit(dataset.T, dataset.T[2], nb_epoch=100, batch_size=1, verbose=1, validation_split=0.05)


# In[ ]:
	
        model = Sequential()
        model.add(LSTM(4, input_dim=1))
        model.add(Dense(1))
        model.compile(loss='mean_squared_error', optimizer='adam')
        model.fit(DS[i][:,0], DS[i][:,2], nb_epoch=100, batch_size=1, verbose=2)



