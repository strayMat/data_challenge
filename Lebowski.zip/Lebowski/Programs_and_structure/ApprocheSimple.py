#Simply putting the same number as the week before, at the same time_slot and the same 

#This scores approx 2.2

from datetime import datetime
from datetime import timedelta
import pandas as pd
from Calculhoraire_exclusif import intervalle
from Calculhoraire_exclusif import centre
from sklearn import tree
import numpy as np


read_name = 'train/train_2011_2012_2013.csv'
print("loading data...")
df = pd.read_csv(read_name, usecols = ['DATE','ASS_ASSIGNMENT'], sep = ";")
print("end loading\n")

print("loading data...")
dsub = pd.read_csv('submission/submission.txt', usecols = ['DATE','ASS_ASSIGNMENT','prediction'], sep = "\t")
print("end loading\n")


df['TIME'] = df['DATE'].apply(lambda x: intervalle(x))
df['DATE'] = df['DATE'].apply(lambda x: datetime.strptime(x,"%Y-%m-%d %H:%M:%S.%f"))
df['ASS_ASSIGNMENT'] = df['ASS_ASSIGNMENT'].apply(lambda x: centre(x))
df['DATE'] = df['DATE'].dt.date
df['DATE'] = df['DATE'].apply(lambda x: datetime.strftime(x,"%Y-%m-%d"))

dsub['TIME'] = dsub['DATE'].apply(lambda x: intervalle(x))
dsub['DATE'] = dsub['DATE'].apply(lambda x: datetime.strptime(x,"%Y-%m-%d %H:%M:%S.%f"))
dsub['short_DATE'] = dsub['DATE'].dt.date

sf = df.groupby(['DATE','ASS_ASSIGNMENT','TIME']).size()

df2 = sf.to_dict()

prediction = []
from math import floor
for row in dsub.iterrows():
    ass = row[1]['ASS_ASSIGNMENT']
    ass = centre(ass)
    if ass == -1: print('warning')
    time = row[1]['TIME']
    s_date = row[1]['short_DATE']
    pred = 0
    for i in range(1):
        s_date = s_date + timedelta(days=-7)
        pred+=df2.get((s_date.strftime("%Y-%m-%d"),ass,time),0)
    pred=floor(pred)
    prediction.append(pred)

dsub['prediction'] = prediction

dsub.to_csv("submission/sortie.txt", columns=['DATE','ASS_ASSIGNMENT','prediction'], sep = '\t', index = False)

