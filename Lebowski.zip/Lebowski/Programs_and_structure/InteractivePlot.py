from datetime import datetime
from datetime import timedelta
import pandas as pd
from Calculhoraire_exclusif import intervalle
from Calculhoraire_exclusif import centre
from sklearn import tree
import numpy as np


read_name = 'train/train_2011_2012_2013.csv'
print("loading data...")
df = pd.read_csv(read_name, usecols = ['DATE','ASS_ASSIGNMENT','CSPL_RECEIVED_CALLS'], sep = ";")
print("end loading\n")

print("Traitement des données...")
df['DATE'] = df['DATE'].apply(lambda x: datetime.strptime(x,"%Y-%m-%d %H:%M:%S.%f"))

start = df.min(axis = 0)

start=start[0]

df['DATE'] = df['DATE'].apply(lambda x: datetime.strftime(x,"%Y-%m-%d %H:%M:%S"))
result = df.groupby(['DATE','ASS_ASSIGNMENT'])['CSPL_RECEIVED_CALLS'].sum()

result=result.to_dict()

print("Fin traitement.\n")

date = start
assignments = df['ASS_ASSIGNMENT'].unique()

total_slots = 55000

to_plot = [[0 for i in range(total_slots)] for j in range(28)]

for index in range(total_slots):
    for a in assignments:
        to_plot[centre(a)][index]=result.get((date.strftime("%Y-%m-%d %H:%M:%S"),a),0)
    date = date+timedelta(minutes=30)

import plotly.plotly as py
import matplotlib.pyplot as plt

x = list(i for i in range(total_slots))
for a in assignments:
    y = list(r for r in to_plot[centre(str(a))])
    line = plt.figure()
    plt.plot(x,y, marker = 'o')
    plt.ylabel(str(a))
    plt.show()
