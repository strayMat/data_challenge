import pandas as pd
import numpy as np
from datetime import datetime
from Calculhoraire_exclusif import centre
from math import exp
from datetime import timedelta

def error(a, dreal2, assignments):
    print("loading data...")
    dsub = pd.read_csv(a+"/sortie.txt", sep = "\t")
    print("end! ")
    
    dsub['DATE'] = dsub['DATE'].apply(lambda x: datetime.strptime(x,"%Y-%m-%d %H:%M:%S.%f"))
    
    errors = [0 for i in range(len(assignments))]
    
    for row in dsub.iterrows():
        ass = row[1]['ASS_ASSIGNMENT']
        date = row[1]['DATE']
        date = date + timedelta(days=-7)
        date = date.strftime("%Y-%m-%d %H:%M:%S")
        date+='.000'
        prediction = row[1]['prediction']
        yreal = dreal2.get((date,ass),0)
        errors[centre(ass)]+=(exp(0.1*(yreal-prediction))-0.1*(yreal-prediction)-1)
    
    error=sum(errors)/82909
    return error
