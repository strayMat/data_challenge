import pandas as pd
import numpy as np
from datetime import datetime
from Calculhoraire_exclusif import intervalle


#on charge les données préprocessées
print("loading data...")
dsub = pd.read_csv("submission/sortie.txt", sep = "\t")
print("end! ")


dsub["DATE"] = dsub["DATE"].apply(lambda x:     datetime.strptime(x,"%Y-%m-%d %H:%M:%S"))
dsub["MONTH"] = dsub["DATE"].dt.month
dsub['short_DATE'] = dsub["DATE"].dt.date

dsub['DAY_WE_DS'] = dsub['DATE'].dt.weekday

dsub['TIME_SLOT'] = dsub["DATE"].apply(lambda x: intervalle(x))

nb_days = len(np.unique(dsub['short_DATE']))
nb_semaines = nb_days/7

print(nb_semaines)

ass = np.unique(dsub.ASS_ASSIGNMENT)
print(ass)

result = pd.DataFrame({'count' : dsub.groupby(['ASS_ASSIGNMENT', 'DAY_WE_DS','TIME_SLOT']).size()}).reset_index()
result["MEAN"] = result["count"]/nb_semaines

print(result)



#plot les graphiques sur une semaine pour chaque assignment center
import plotly.plotly as py
import matplotlib.pyplot as plt

#créer les abcisses pour le weekplot
result['WK_TIME_SLOT'] = result['TIME_SLOT'] + 48*result['DAY_WE_DS']

for a in ass:
    a_ass = result[result.ASS_ASSIGNMENT == str(a)]

    x = list(a_ass.WK_TIME_SLOT)
    y = list(a_ass.MEAN)
    str_a = a.decode("ascii", "ignore")
    line = plt.figure()
    plt.plot(x,y)
    plt.title("nombre appels pour le centre : " + str_a + " au cours de la semaine")
    #plt.show()
    plt.savefig('week_scatterplot/week_of_'+str(a)+'.png')
plt.clf()
